"""固定マスタ（星凪諸島）。何度呼んでも増えない（固定 id + INSERT OR IGNORE / UPDATE）。

ここの内容は架空。旅人の声は SNS 風のダミーで、本番では外部 API 等に差し替える前提。
"""
from __future__ import annotations

import sqlite3

# id, name, area, svg_key, description, access, best_season, map_x, map_y
SPOTS = [
    (1, "風詠みの灯台（白波離島）", "白波離島", "lighthouse",
     "島の北端に立つ白い灯台。風の音が歌のように聞こえることから名がついた。晴れた日は水平線が丸く見える。",
     "星綴港から連絡船 25 分、灯台まで徒歩 10 分", "summer", 68, 52),
    (2, "星綾の潮見台（星凪諸島・薄青岬）", "薄青岬", "cape",
     "岬の先の木の展望台。夕方は潮が引いて星の形の岩が現れる。夜は本物の星が海に映る。",
     "バス「薄青岬」下車、徒歩 15 分", "autumn", 352, 86),
    (3, "虹灯りの夜市（虹帆町）", "虹帆町", "market",
     "日が落ちると色とりどりの提灯が灯る通り。屋台と小さな食堂が並び、夏は灯籠流しも。",
     "星綴港から徒歩 20 分、または巡回バス 5 分", "summer", 196, 150),
    (4, "瑠璃凪の水鏡湖（雫森谷）", "雫森谷", "lake",
     "風のない朝は空をそのまま映す湖。秋は紅葉が水面に二重に映る。湖畔に小さなカフェがひとつ。",
     "巡回バス「雫森谷口」下車、遊歩道 20 分", "autumn", 88, 218),
    (5, "月花の風車丘（月灯集落）", "月灯集落", "windmill",
     "三つの風車が回る丘。春は菜の花、夏はひまわりが一面に。丘の下にパン屋の煙突が見える。",
     "星綴港から自転車 30 分（坂道あり）", "spring", 292, 152),
    (6, "灯雲の石畳通り（星綴港）", "星綴港", "street",
     "港から続く石畳の坂道。古い宿とガラス工房が並び、夕方は家々の灯りが雲に映る。",
     "星綴港 船着場から徒歩 3 分", "winter", 215, 232),
    (7, "雪雫の音楽堂（鈴風高原）", "鈴風高原", "hall",
     "高原の木造ホール。冬は雪の中に灯りがともり、秋はススキ野原で小さな演奏会が開かれる。",
     "巡回バス「鈴風高原」下車すぐ", "winter", 138, 132),
]

# id, spot_id, name, area, category, open, close, closed_weekday(月=0..日=6, None=無休), rate, is_unmanned, svg_key, description, access, best_season
SHOPS = [
    (1, 1, "白波離島 灯台ガイド詰所", "白波離島", "体験", "09:00", "17:00", None, 10, 0, "stand",
     "灯台のふもとの小さな詰所。ボランティアガイドの舟木さんが灯台と島の話をしながら一周 40 分の散歩に連れていってくれる。", "灯台の下", "summer"),
    (2, 2, "薄青岬 観光案内所（売店つき）", "薄青岬", "物販", "10:00", "18:00", None, 10, 0, "stand",
     "潮見台の入口にある観光案内所。案内役の浜田さんが干潮の時刻と星の見え方を教えてくれる。岬の塩ラムネや干し芋の売店も。", "潮見台の入口", "autumn"),
    (3, 3, "夜市食堂 虹のかけら", "虹帆町", "飲食", "16:00", "22:00", 0, 10, 0, "diner",
     "夜市の真ん中にある八席の食堂。季節の魚と新米のおにぎりが名物。店主の明石さんが一人で切り盛り。", "夜市の中ほど", "summer"),
    (4, 4, "湖畔カフェ 水鏡", "雫森谷", "飲食", "09:00", "17:00", 1, 10, 0, "cafe",
     "水鏡湖の岸に立つ木の小屋。窓いっぱいに湖が映る。朝霧の時間が一番きれいだと水野さんは言う。", "湖畔遊歩道の終点", "autumn"),
    (5, 5, "月花ベーカリー", "月灯集落", "飲食", "08:00", "15:00", 0, 10, 0, "bakery",
     "風車丘の下のパン屋。石窯で焼く季節のパン。売り切れ次第おしまい。望月さんが毎朝 5 時から焼く。", "風車丘のふもと", "spring"),
    (6, 6, "石畳の宿 灯雲荘", "星綴港", "宿泊", "15:00", "21:00", None, 10, 0, "inn",
     "石畳通りの古い宿。囲炉裏のある広間と、港が見える 5 部屋。主人の三浦さんは元漁師。", "石畳通りの中ほど", "winter"),
    (7, 6, "港の工房 星綴ガラス", "星綴港", "体験", "10:00", "17:00", 3, 10, 0, "glass",
     "石畳通りの端のガラス工房。吹きガラスの体験ができる。藤井さんが季節の色を一緒に選んでくれる。", "石畳通りの坂上", "winter"),
    (8, 7, "高原の茶屋 雪雫", "鈴風高原", "飲食", "10:00", "16:00", 2, 10, 0, "teahouse",
     "音楽堂のとなりの茶屋。高原のお茶と季節の甘味。鈴木さんは音楽堂の管理人でもある。", "音楽堂のとなり", "winter"),
]

# id, shop_id, name, intro, svg_key, role
PEOPLE = [
    (1, 3, "明石さん", "夜市食堂の店主。魚をさばく手が早い。旅人の顔を一度で覚える。", "akari", "店主"),
    (2, 4, "水野さん", "湖畔カフェの店主。朝霧の湖を毎日写真に撮っている。", "rui", "店主"),
    (3, 5, "望月さん", "パン屋の店主。焼きたてを一つ、必ずおまけしてくれる。", "tsukino", "店主"),
    (4, 6, "三浦さん", "宿の主人。元漁師。囲炉裏の夜話が長い。", "minato", "宿の主人"),
    (5, 7, "藤井さん", "ガラス職人。季節の色をガラスに閉じ込める。", "tsuzuri", "職人"),
    (6, 8, "鈴木さん", "茶屋の店主で音楽堂の管理人。鈴の音のような笑い声。", "suzu", "店主"),
    (7, 2, "浜田さん", "岬の観光案内所の案内役。干潮の時刻と星の出る方角を毎日手帳に書いている。", "nagi", "観光案内所"),
    (8, 1, "舟木さん", "灯台のボランティアガイド。元灯台守。風の音を聞き分けて天気を当てる。", "ho", "ガイド"),
]

# id, person_id, season, title, note, start_md, end_md
PROMISES = [
    (1, 1, "spring", "桜えびのかき揚げ", "春の夜市は桜えびの香り。揚げたてをどうぞ。", None, None),
    (2, 1, "summer", "夜市の灯籠流し", "夏の終わりの灯籠流し。一緒に流しましょう。", "07-20", "08-10"),
    (3, 1, "autumn", "新米の焼きおにぎり", "秋は新米。焼きおにぎりを取っておきます。", None, None),
    (4, 1, "winter", "星凪おでん", "冬の夜市は星凪おでん。大根が一番人気。", "12-01", "02-28"),
    (5, 2, "spring", "湖畔の桜ミルク", "湖の桜が咲く二週間だけの桜ミルク。", "04-01", "04-20"),
    (6, 2, "summer", "水鏡の朝霧コーヒー", "夏の朝 6 時、霧の湖を見ながらの一杯。", None, None),
    (7, 2, "autumn", "紅葉の湖面ラテ", "紅葉が湖に映る頃のラテ。窓際を空けておきます。", "10-20", "11-15"),
    (8, 2, "winter", "凍る湖の見える窓際席", "湖が凍る朝は、窓際の席をどうぞ。", None, None),
    (9, 3, "spring", "よもぎあんぱん", "丘のよもぎで作るあんぱん。春だけ。", None, None),
    (10, 3, "summer", "ひまわり畑の丘パン", "ひまわりの種をのせた丘パン。", None, None),
    (11, 3, "autumn", "栗のクロワッサン", "集落の栗をたっぷり。朝一番に焼きます。", None, None),
    (12, 3, "winter", "風車の星型シュトレン", "冬の星型シュトレン。予約しておきますね。", "12-01", "12-25"),
    (13, 4, "spring", "朝釣りの船", "春の朝、港から釣り船を出します。", None, None),
    (14, 4, "summer", "浜の花火が見える部屋", "夏祭りの花火が見える角部屋を。", "08-01", "08-15"),
    (15, 4, "autumn", "港の収穫祭ごはん", "収穫祭の夜は囲炉裏で大鍋。", "11-01", "11-10"),
    (16, 4, "winter", "囲炉裏の夜話", "雪の夜は囲炉裏で長い話を。", None, None),
    (17, 5, "spring", "春色の一輪挿し", "春の色で一輪挿しを吹きましょう。", None, None),
    (18, 5, "summer", "海色のグラス", "夏の海の色のグラス。", None, None),
    (19, 5, "autumn", "灯り色のランプ", "秋は灯り色のランプを一緒に。", None, None),
    (20, 5, "winter", "雪の結晶オーナメント", "冬だけの雪の結晶。窓に吊るしてください。", "12-01", "01-31"),
    (21, 6, "spring", "高原の新茶", "五月の新茶を一番に淹れます。", "05-01", "05-31"),
    (22, 6, "summer", "鈴風の冷やし甘酒", "高原の風と冷やし甘酒。", None, None),
    (23, 6, "autumn", "音楽堂のススキ野点", "ススキ野原で小さなお茶会。", "10-10", "10-31"),
    (24, 6, "winter", "雪見ぜんざい", "雪の音楽堂でぜんざいを。", None, None),
    (25, 7, "spring", "春の大潮の星岩", "春の大潮は星の岩が一番大きく現れます。時刻を教えます。", "03-20", "04-10"),
    (26, 7, "summer", "岬の流れ星の夜", "夏の流れ星、岬の先で一緒に数えましょう。", "08-10", "08-15"),
    (27, 7, "autumn", "干し芋の初物", "秋の干し芋ができたら、ひと切れ取っておきます。", None, None),
    (28, 7, "winter", "冬の星座の案内", "空気が澄む冬、星座の見方を案内します。", None, None),
    (29, 8, "spring", "春の渡り鳥の灯台歩き", "渡り鳥が戻る春、灯台まで一緒に歩きましょう。", "04-10", "05-10"),
    (30, 8, "summer", "灯台の夕涼み", "夏の夕方、灯台のテラスで風に当たりましょう。", None, None),
    (31, 8, "autumn", "秋風の音あて", "秋の風の音を聞き分ける遊び。当たったら島の塩キャラメル。", None, None),
    (32, 8, "winter", "冬の灯台の点灯", "冬は 16 時半に灯がともります。一緒に見ましょう。", "12-01", "01-31"),
]

# id, category, name, face_value, weight, stock(None=無制限), enabled
PRIZES = [
    (1, "飲食", "飲食クーポン 500 円引き", 500, 30, 50, 1),
    (2, "宿泊", "宿泊クーポン 1,000 円引き", 1000, 5, 5, 1),
    (3, "体験", "体験クーポン 500 円引き", 500, 15, 20, 1),
    (4, "物販", "物販クーポン 300 円引き", 300, 20, 30, 1),
    (5, "miss", "はずれ", 0, 30, None, 1),
]

# target_type, target_id, season, author, text, hashtags
VOICES = [
    ("spot", 1, "summer", "@shiranami_photo", "灯台の下で風の音を録音。本当に歌ってるみたいだった。", "#星凪諸島 #風詠みの灯台"),
    ("spot", 1, "spring", "@tabi_no_memo", "連絡船から見た灯台が一番きれい。朝の便がおすすめ。", "#白波離島 #朝の船"),
    ("spot", 1, "winter", "@umi_to_sora", "冬の灯台は風が強いけど空が澄んでて、遠くの島まで見えた。", "#風詠みの灯台 #冬の海"),
    ("spot", 2, "autumn", "@hoshi_meguri", "潮が引いて星の岩が出てくる瞬間に立ち会えた。17 時ごろ。", "#星綾の潮見台 #干潮"),
    ("spot", 2, "summer", "@yoru_sanpo", "夜の潮見台、海に星が映って上下どっちが空かわからなくなる。", "#薄青岬 #星空"),
    ("spot", 2, "autumn", "@shio_ramune", "入口のスタンドの塩ラムネ、潮見台で飲むと倍おいしい。", "#星凪諸島 #塩ラムネ"),
    ("spot", 3, "summer", "@niji_lantern", "提灯が全部灯る 18 時半。通りが虹の色になる。", "#虹灯りの夜市 #提灯"),
    ("spot", 3, "autumn", "@tabi_no_memo", "夜市の食堂で新米の焼きおにぎり。秋に来てよかった。", "#虹帆町 #焼きおにぎり"),
    ("spot", 3, "winter", "@fuyu_no_tabi", "冬の夜市は人が少なくて、おでんの湯気と提灯だけ。それがいい。", "#虹灯りの夜市 #おでん"),
    ("spot", 4, "autumn", "@mizukagami_am", "朝 7 時、湖に紅葉が二重に映ってた。カフェの窓から。", "#瑠璃凪の水鏡湖 #紅葉"),
    ("spot", 4, "summer", "@kiri_no_asa", "朝霧の湖は 6 時台だけ。寝坊しないで。", "#雫森谷 #朝霧"),
    ("spot", 4, "spring", "@hana_to_mizu", "湖畔の桜が水面に映る季節。桜ミルク飲みながら。", "#水鏡湖 #桜"),
    ("spot", 5, "spring", "@kaze_guruma", "風車の丘が菜の花で黄色一色。坂はきついけど登る価値あり。", "#月花の風車丘 #菜の花"),
    ("spot", 5, "summer", "@himawari_day", "ひまわりと風車。丘の下のパン屋の匂いが上まで届く。", "#月灯集落 #ひまわり"),
    ("spot", 5, "autumn", "@pan_meguri", "栗のクロワッサン目当てに朝一で。売り切れ前に買えた。", "#月花ベーカリー #栗"),
    ("spot", 6, "winter", "@ishidatami_ya", "夕方、家の灯りが低い雲に映って石畳がオレンジ色に。", "#灯雲の石畳通り #星綴港"),
    ("spot", 6, "autumn", "@glass_iro", "工房で灯り色のランプを吹いた。秋の色。", "#星綴ガラス #吹きガラス"),
    ("spot", 6, "winter", "@irori_night", "宿の囲炉裏で夜話。外は雪、中はあったかい。", "#灯雲荘 #囲炉裏"),
    ("spot", 7, "winter", "@yuki_hall", "雪の中の音楽堂、灯りがついた瞬間に息をのんだ。", "#雪雫の音楽堂 #雪"),
    ("spot", 7, "autumn", "@susuki_note", "ススキ野原の野点に偶然参加。鈴木さんのお茶。", "#鈴風高原 #野点"),
    ("spot", 7, "spring", "@shincha_love", "五月の新茶を音楽堂のテラスで。風が鈴の音みたい。", "#高原の茶屋 #新茶"),
    ("shop", 3, "autumn", "@tabi_gohan", "明石さんの焼きおにぎり、外はカリッと中はほくほく。", "#虹のかけら #夜市ごはん"),
    ("shop", 3, "summer", "@lantern_river", "灯籠流しのあとに食堂で冷たい麦茶。夏の夜。", "#虹のかけら #灯籠流し"),
    ("shop", 4, "autumn", "@latte_art_m", "紅葉の湖面ラテ。窓際を取っておいてくれた。", "#湖畔カフェ水鏡 #ラテ"),
    ("shop", 4, "winter", "@fuyu_mado", "湖が凍る朝、窓際の席で一時間ぼーっとした。", "#水鏡 #冬の湖"),
    ("shop", 5, "winter", "@stollen_fan", "星型のシュトレン、予約して正解。", "#月花ベーカリー #シュトレン"),
    ("shop", 5, "spring", "@anpan_asa", "よもぎあんぱん、春だけ。望月さんのおまけつき。", "#月花ベーカリー #よもぎ"),
    ("shop", 6, "winter", "@minato_stay", "三浦さんの夜話は長いけど、全部おもしろい。", "#灯雲荘 #宿"),
    ("shop", 6, "autumn", "@shukaku_nabe", "収穫祭の大鍋。泊まってよかった。", "#灯雲荘 #収穫祭"),
    ("shop", 7, "winter", "@yuki_kesshou", "雪の結晶オーナメント、窓に吊るしたら部屋が冬になった。", "#星綴ガラス #オーナメント"),
    ("shop", 7, "summer", "@umi_iro_glass", "海色のグラス、藤井さんと色を選ぶ時間が楽しい。", "#星綴ガラス #体験"),
    ("shop", 8, "winter", "@zenzai_yuki", "雪見ぜんざい。音楽堂の灯りを見ながら。", "#茶屋雪雫 #ぜんざい"),
    ("shop", 8, "summer", "@amazake_kaze", "冷やし甘酒と高原の風。鈴木さんの笑い声。", "#茶屋雪雫 #甘酒"),
    ("shop", 1, "summer", "@kaze_walk", "舟木さんのガイドで灯台まで。風の音の話が面白くて 40 分があっという間。", "#灯台ガイド #白波離島"),
    ("shop", 1, "winter", "@tou_dai_fuyu", "冬の点灯を舟木さんと見た。16 時半、灯がともる瞬間。", "#風詠みの灯台 #点灯"),
    ("shop", 2, "autumn", "@hoshiimo_cape", "案内所の浜田さんに干潮の時刻を聞いて正解。星の岩が見えた。", "#薄青岬 #観光案内所"),
    ("shop", 2, "summer", "@nagareboshi_misaki", "浜田さんと流れ星を数えた夜。12 個。", "#薄青岬 #流れ星"),
]


def seed_master(conn: sqlite3.Connection) -> None:
    conn.executemany(
        "INSERT OR IGNORE INTO spots(id,name,area,svg_key,description,access,best_season,map_x,map_y) VALUES(?,?,?,?,?,?,?,?,?)",
        SPOTS,
    )
    conn.executemany(
        "INSERT OR IGNORE INTO shops(id,spot_id,name,area,category,open_time,close_time,closed_weekday,rate_percent,is_unmanned,svg_key,description,access,best_season) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        SHOPS,
    )
    # 地図の座標は写真に合わせて更新する
    conn.executemany("UPDATE spots SET map_x = ?, map_y = ? WHERE id = ?", [(s[7], s[8], s[0]) for s in SPOTS])
    # 旧版（無人店 2 件）の DB を上書きして、全部の店に人が付く状態にする。
    # 運営の窓で編集できる列（営業時間・定休日・紹介・行き方）は触らない（起動やデモ初期化のたびに編集が消えないように）
    conn.executemany(
        "UPDATE shops SET spot_id=?, name=?, area=?, category=?, is_unmanned=?, svg_key=?, best_season=? WHERE id=?",
        [(s[1], s[2], s[3], s[4], s[9], s[10], s[13], s[0]) for s in SHOPS],
    )
    conn.executemany("INSERT OR IGNORE INTO people(id,shop_id,name,intro,svg_key,role) VALUES(?,?,?,?,?,?)", PEOPLE)
    conn.executemany("UPDATE people SET name=?, role=?, intro=? WHERE id=?", [(p[2], p[5], p[3], p[0]) for p in PEOPLE])
    rename_people(conn)
    conn.executemany(
        "INSERT OR IGNORE INTO promises(id,person_id,season,title,note,start_md,end_md) VALUES(?,?,?,?,?,?,?)", PROMISES
    )
    conn.executemany(
        "INSERT OR IGNORE INTO prizes(id,category,name,face_value,weight,stock,enabled) VALUES(?,?,?,?,?,?,?)", PRIZES
    )
    if conn.execute("SELECT COUNT(*) AS c FROM voices").fetchone()["c"] != len(VOICES):
        conn.execute("DELETE FROM voices")
        conn.executemany(
            "INSERT INTO voices(target_type,target_id,season,author,text,hashtags) VALUES(?,?,?,?,?,?)", VOICES
        )
    # 主人公
    conn.execute(
        "INSERT OR IGNORE INTO users(id,name,source) VALUES(?,?,?)",
        (8800001, "test_traveler_0001", "seed"),
    )


# 会える人の名前を、より自然な名前（苗字 + さん）に改めたときの置き換え表。旧 → 新。
# 既存の DB に残っている文章（店の紹介・約束・旅人の声・お店からの便りなど）の中の旧名も、起動時に置き換える（何度実行しても同じ結果）。
PEOPLE_RENAMES = [
    ("灯里さん", "明石さん"), ("瑠衣さん", "水野さん"), ("月乃さん", "望月さん"), ("港さん", "三浦さん"),
    ("綴さん", "藤井さん"), ("鈴さん", "鈴木さん"), ("凪さん", "浜田さん"), ("帆さん", "舟木さん"),
]
_RENAME_TARGETS = [
    ("shops", ["description", "recommend", "notes", "access"]),
    ("promises", ["title", "note"]),
    ("voices", ["author", "text", "hashtags"]),
    ("messages", ["title", "body"]),
    ("wishes", ["label"]),
    ("events", ["title", "note"]),
]


def rename_people(conn: sqlite3.Connection) -> int:
    """旧名が残っている行だけ書き換える。利用者が自分で書いた一言（diaries）は触らない。"""
    changed = 0
    for table, cols in _RENAME_TARGETS:
        have = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
        for col in cols:
            if col not in have:
                continue
            for old, new in PEOPLE_RENAMES:
                cur = conn.execute(f"UPDATE {table} SET {col} = REPLACE({col}, ?, ?) WHERE {col} LIKE ?", (old, new, f"%{old}%"))
                changed += cur.rowcount
    return changed
